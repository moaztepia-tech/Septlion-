import './globals.css';
export const metadata={title:'SEPTLION — B2B Operating Infrastructure',description:'Discovery to RFQ to Quote to Order Intent'};
export default function RootLayout({children}:{children:React.ReactNode}){return <html lang="en"><body>{children}</body></html>}
